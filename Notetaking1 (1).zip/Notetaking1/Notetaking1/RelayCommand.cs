﻿using System;
using System.Windows.Input;

namespace NoteTakingApp
{
    public class RelayCommand : ICommand
    {
        // Action to execute when the command is triggered
        private readonly Action _execute;

        // Function to determine whether the command can execute
        private readonly Func<bool> _canExecute;

        // Constructor accepting an execute action
        public RelayCommand(Action execute) : this(execute, null)
        {
        }

        // Constructor accepting both an execute action and a can-execute condition
        public RelayCommand(Action execute, Func<bool> canExecute)
        {
            _execute = execute ?? throw new ArgumentNullException(nameof(execute));
            _canExecute = canExecute;
        }

        // Event to notify changes in whether the command can be executed
        public event EventHandler CanExecuteChanged
        {
            add => CommandManager.RequerySuggested += value;  // Subscribing to CanExecuteChanged event
            remove => CommandManager.RequerySuggested -= value;  // Unsubscribing from the event
        }

        // Determines whether the command can execute
        public bool CanExecute(object parameter)
        {
            return _canExecute == null || _canExecute();  // If no canExecute logic, always true
        }

        // Executes the command action
        public void Execute(object parameter)
        {
            _execute();  // Calls the method passed in the constructor
        }
    }
}
