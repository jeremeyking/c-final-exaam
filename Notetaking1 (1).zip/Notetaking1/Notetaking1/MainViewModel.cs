﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Input;

namespace NoteTakingApp
{
    public class MainViewModel : INotifyPropertyChanged
    {
        public ObservableCollection<Note> Notes { get; set; }
        private Note _selectedNote;

        public Note SelectedNote
        {
            get => _selectedNote;
            set
            {
                _selectedNote = value;
                OnPropertyChanged(nameof(SelectedNote));
            }
        }

        // Commands
        public ICommand AddNoteCommand { get; }
        public ICommand DeleteNoteCommand { get; }

        public MainViewModel()
        {
            // Initial notes
            Notes = new ObservableCollection<Note>
            {
                new Note { Title = "Sample Note", Content = "This is a sample note." },
                new Note { Title = "Another Note", Content = "This is another sample note." }
            };

            // Initialize commands
            AddNoteCommand = new RelayCommand(AddNote);
            DeleteNoteCommand = new RelayCommand(DeleteNote);
        }

        public void AddNote()
        {
            // Create a new note
            var newNote = new Note
            {
                Title = "New Note",
                Content = "Type your note here."
            };

            // Add the new note to the ObservableCollection
            Notes.Add(newNote);

            // Set the newly created note as the selected note
            SelectedNote = newNote;
        }

        public void DeleteNote()
        {
            if (SelectedNote != null)
            {
                Notes.Remove(SelectedNote);
                SelectedNote = null; // Reset the selection
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string name) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}

